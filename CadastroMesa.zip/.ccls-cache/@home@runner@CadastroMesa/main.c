#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef char Str20[20];


struct ListaItens{
   Str20 nome;
   int Id;
   float preco;
   struct ListaItens *prox;
};
typedef struct ListaItens Lista;

struct Mesa{
  int ID;
  Str20 EstadoDaMesa;
  Lista *produtos;
};
typedef struct Mesa tpMesa;
tpMesa lista[20];
int indice=0;

void IniciaPrograma(){
  tpMesa atual;
  for(int i = 0; i < 5; i++ ){
    lista[i].ID = i;
    strcpy(lista[i].EstadoDaMesa, "livre");
    indice++;
  }
}

void AbrirMesa(){
  int numero, id, resp=1;
  Lista *Aux, *Novo = malloc(sizeof(Lista));
  float preco;
  Str20 nome;
  do{
  printf("Qual o numero da mesa que quer acessar?: ");
  scanf("%i", &numero);
  printf("Mesa: %i\n", lista[numero].ID);
  if(lista[numero].produtos == NULL){ 
   lista[numero].produtos = (Lista *)malloc(sizeof(Lista));
   printf("Nome do produto: ");
   scanf("%s", nome);
   strcpy(lista[numero].produtos->nome,nome);
   printf("%s\n", lista[numero].produtos->nome);
   printf("ID do Produto: ");
   scanf("%i", &id);
   lista[numero].produtos->Id = id;
   printf("%i\n", lista[numero].produtos->Id );
   printf("Preço: ");
   scanf("%f", &preco);
   printf("Aperte <1> para Continuar, <outro valor> para Parar");
   scanf("%i", &resp);
  } else {
    if(lista[numero].produtos->prox == NULL){
      printf("passou\n");
      Aux = (Lista *)malloc(sizeof(Lista));
      printf("Nome do produto: ");
      scanf("%s", nome);
      strcpy(Aux->nome,nome);
      printf("%s\n", Aux->nome);
      printf("ID do Produto: ");
      scanf("%i", &id);
      Aux->Id = id;
      printf("%i\n", Aux->Id );
      printf("Preço: ");
      scanf("%f", &preco);
      lista[numero].produtos->prox = Aux;
      printf("Aperte <1> para Continuar, <outro valor> para Parar");
      scanf("%i", &resp);
    } else {
      printf("passou 2\n");
      printf("Nome do produto: ");
      scanf("%s", nome);
      strcpy(Novo->nome,nome);
      printf("%s\n", Novo->nome);
      printf("ID do Produto: ");
      scanf("%i", &id);
      Novo->Id = id;
      printf("%i\n", Novo->Id );
      printf("Preço: ");
      scanf("%f", &preco);
      Novo->prox = NULL;
      Aux = lista[numero].produtos;
      while(Aux->prox){
        printf("%i", Aux->Id);
        Aux = Aux->prox;
      }
      Aux->prox = Novo;
      break;
    }
  }
    }while(resp == 1);
}
void FecharMesa(){}
void Adicionar(){}
void Remover(){}
void ContaParcial(){}
void ListarMesas(){
  for(int i= 0; i < indice; i++){
    printf("Mesa %i \n", lista[i].ID);
 }
}
void ListarProdutos(){
  int numero;
  Lista *Aux;
  printf("Qual o numero da mesa que quer acessar?: ");
  scanf("%i", &numero);
  if(lista[numero].produtos != NULL){
    Aux = lista[numero].produtos;
    do{
      printf("produtos: %s\n", Aux->nome);
      Aux = Aux->prox;
    }while(Aux != NULL);
  } else {
    printf("\nNão existe produto na Mesa\n\n");
  }
}

int main(void) {
  IniciaPrograma();
  int Opcao;
  do{
    printf("    >>>>>>>>> Bar do Zé <<<<<<<<<\n\n");
    printf(" Deseja fazer o que?\n");
    printf("1 - Abrir Mesa\n");
    printf("2 - Fechar Mesa\n");
    printf("3 - Adicionar Itens na Mesa\n");
    printf("4 - Remover Itens na Mesa\n");
    printf("5 - Ver a conta parcial da Mesa\n");
    printf("6 - Ver quais Mesas Livres/Ocupadas\n");
    printf("7 - Sair\n");
    scanf("%d", &Opcao);
    switch(Opcao){
      case 1: AbrirMesa(); break;
      case 2: FecharMesa(); break;
      case 3: Adicionar(); break;
      case 4: Remover(); break;
      case 5: ContaParcial(); break;
      case 6: ListarMesas(); break;
      case 8: ListarProdutos(); break;
      default: printf("São numeros de 1 ate 7, tente novamente"); break;}}
    while (Opcao != 7);
  return 0;
}